﻿using UnityEngine;
using System.Collections;

public class ItemProperties : MonoBehaviour {

	public int[] body_part_ids;

	void Start () {
	
	}


	void Update () {
	
	}
}
