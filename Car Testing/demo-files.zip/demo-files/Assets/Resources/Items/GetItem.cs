﻿using UnityEngine;
using System.Collections;

public class GetItem : MonoBehaviour {


	void Start () {
	
	}
	

	void Update () {
	
	}
}
